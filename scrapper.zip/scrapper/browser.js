const puppeteer = require("puppeteer");
const browserEndPoint = "ws://127.0.0.1:9222/devtools/browser/c8271faf-8346-48d9-89c2-a4252108c93f";
async function startBrowser() {
    let browser;
    try {
        console.log("Opening the browser......");
        browser = await puppeteer.connect({
            headless: true,
            args: [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-extensions",
                "--ignore-certificate-errors",
            ],
            ignoreHTTPSErrors: true,
            browserWSEndpoint: browserEndPoint,
        });
    } catch (err) {
        console.log("Could not create a browser instance => : ", err);
    }
    return browser;
}

module.exports = {
    startBrowser,
};