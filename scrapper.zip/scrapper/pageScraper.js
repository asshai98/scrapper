const ObjectsToCsv = require("objects-to-csv");
const scraper = {
    url: "https://www.amazon.com/s?rh=n%3A16225007011&fs=true&ref=lp_16225007011_sar",
    items: [],
    async scraper(browser) {
        for (let i = 2; i < 5; i++) {
            this.url = `https://www.amazon.com/s?i=computers-intl-ship&rh=n%3A16225007011&fs=true&page=${i}&qid=1643287492&ref=sr_pg_2`;
            let page = await browser.newPage();

            await page.goto(this.url);
            await page.setDefaultNavigationTimeout(0);
            await page.waitForSelector("#a-page");

            const links = await page.evaluate(async() => {
                const links = [];

                const elements = await document.querySelectorAll(
                    ".a-link-normal.s-link-style.a-text-normal"
                );

                for (let el of elements) {
                    const link = await el.href;
                    links.push(link);
                }

                return links;
            });

            const uniqueLinks = [...new Set(links)];

            for (let uniqueLink of uniqueLinks) {
                await page.goto(uniqueLink);

                await page.waitForSelector("#dp");

                const item = await page.evaluate(async() => {
                    return {
                        title: await document
                            .querySelector("#productTitle")
                            .textContent.trim(),
                        ratingStars: await document
                            .querySelector(".a-icon-alt")
                            .textContent.trim(),
                        ratingTotal: await document
                            .querySelector("#acrCustomerReviewText")
                            .textContent.trim(),
                        brand: await document
                            .querySelector(".a-size-base")
                            .textContent.trim(),
                        shipping: await document
                            .querySelector("#contextualIngressPtLabel_deliveryShortLine")
                            .textContent.trim(),
                    };
                });

                this.items.push(item);
            }

            continue;
        }

        let csv = new ObjectsToCsv(this.items);

        await csv.toDisk('./amazon1.csv');

        console.log(this.items.length);
    }
};

module.exports = scraper;